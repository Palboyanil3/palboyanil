import EarthCanvas from "./Earth";
import ComputersCanvas from "./Computers";
import StarsCanvas from "./Stars";

export { EarthCanvas, ComputersCanvas, StarsCanvas };
